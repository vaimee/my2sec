/*---------------------------------------------------------\
|| aw_api_client.js: ACTIVITY WATCH CLIENT API LIBRARY
|| 	DATE: 28/06/2022
|| 	AUTHOR: Gregorio Monari
|| 	DESCRIPTION: a collection of functions used to 
||     get and post data to the localhost Activity Watch API
\\--------------------------------------------------------*/
console.log("-> Loaded external script: aw_api_lib.js")



//======================================
// AW PRODUCER BUCKET AND EVENT HANDLERS
//======================================
//------------------------------
//NAME: create_producer_bucket(JsonElement json_obj)
//DESCRIPTION: creates a new "aw-producer" bucket. Does nothing if already exists
//NOTES:
function create_producer_bucket(json_obj){

	return new Promise(resolve=>{
		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer"
		req.open("POST", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"create_bucket: aw-producer bucket created, status "+this.status)
        		resolve("ok")
    		}else{

    			if (this.readyState === XMLHttpRequest.DONE && this.status === 304) {
    				consoleLog(1,"create_bucket: aw-producer bucket already existing, status "+this.status)
    				resolve("ok")
    			}

    		}
		}
		req.send("{ \"client\": \"aw-producer\", \"type\": \"sepaconnector\", \"hostname\": \"unknown\"}");	
	});

}




async function update_event(json_obj,json_event){

		var event= await get_events(jsonConfig,'aw-producer')
		//SE ESISTE GIA', ELIMINALO
		if (event.length>0) {
			await delete_event(jsonConfig,event[0].id)	
		}
		await create_event(jsonConfig,json_event)

}



function create_event(json_obj,json_event){

	return new Promise(resolve=>{

		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer/events"
		req.open("POST", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"create_event: aw-producer event created, status "+this.status)
        		resolve("ok")
    		}
		}
		//bodystring="{ \"timestamp\": \"2022-07-12T16:47:46.060Z\", \"duration\": 0, \"data\": {\"last_update\":\""+get_time()+"\"} }"
		req.send(json_event);	

	});
}




function delete_event(json_obj,event_ID){
	consoleLog(0,"removing event")
	return new Promise(resolve=>{

		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer/events/"+event_ID;
		req.open("DELETE", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"remove_event: aw-producer event n."+event_ID+" deleted, status "+this.status)
        		resolve("ok")
    		}
		}
		req.send();	
	});
}










//===========================
// BUCKETS AND EVENTS QUERIES
//===========================
//--------------------------------------
//NAME: get_events(JsonElement json_obj)
//DESCRIPTION: gets the events produced by 1 specific watcher
async function query_events(json_obj,watcher_id,end_time,start_time){
	consoleLog(1,"get_events: fetching events of "+watcher_id+"...")
	//WAIT TO GET THE JSON, with query example: ?end=2022-07-17T15%3A23%3A55Z&start=2022-07-16T15%3A23%3A55Z
	var path="/api/0/buckets/"+watcher_id+"/events?end="+end_time+"&start="+start_time;
	path=path.replace(/:/g,"%3A"); //REPLACE : FOR A WELL FORMATTED REQUEST
	consoleLog(0,"query_events: reqpath: "+path)
	
	var jsonEvents = await api_GetJson(json_obj,path) //path
	//RETURN THE WATCHERS
	return new Promise(resolve=>{
  		consoleLog(1,"get_events: fetched events correctly!")
  		resolve(jsonEvents)
	});
	
}




//--------------------------------------
//NAME: get_events(JsonElement json_obj)
//DESCRIPTION: gets the events produced by 1 specific watcher
async function get_events(json_obj,watcher_id){
	consoleLog(1,"get_events: fetching events of "+watcher_id+"...")
	//WAIT TO GET THE JSON
	var jsonEvents = await api_GetJson(json_obj,"/api/0/buckets/"+watcher_id+"/events")
	//RETURN THE WATCHERS
	return new Promise(resolve=>{
  		consoleLog(1,"get_events: fetched events correctly!")
  		resolve(jsonEvents)
	});
}

//----------------------------------------------
//NAME: get_watchers(JsonElement json_obj)
//DESCRIPTION: gets data from AW API and prints the resulting String on a TextArea
//ARGUMENTS: json_object (hostname and port of aw api)
//RETURNS: json_object (raw data containing the active watchers in the computer)
async function get_watchers(json_obj){
	//WAIT TO GET THE JSON
	consoleLog(1,"get_watchers: fetching watchers...")
	var jsonWatchers = await api_GetJson(json_obj,"/api/0/buckets/")
	//RETURN THE WATCHERS
	return new Promise(resolve=>{
  		consoleLog(1,"get_watchers: fetched watchers correctly!")
  		resolve(jsonWatchers)
	});

}



//===========================
// ROOT FUNCTIONS
//===========================
//--------------------------------------------
//NAME: get_aw_configuration(String file_path)
//DESCRIPTION: reads a host.jsap file and returns the json object
//ARGUMENTS: String file_path (the path to the file)
//RETURNS: a json object containing the file properties
//NOTES:
function get_aw_configuration(file_path){
	return new Promise(resolve=>{
		//GET CONFIG FILE
		fetch(file_path)
		.then(response => response.text())
		.then(data => {
			var jsonConfig=JSON.parse(data)
			consoleLog(1,"init: parsed json (AW configuration file)")
			//console.log(jsonConfig)
			resolve(jsonConfig)	
		});
	});
}


//======================================================//
//	/|\ [THE ROOT, ALLOWS TO CONNECT WITH THE API]		//
// 	\|/	  ______________________________________		//
//	 |___|______________________________________|___	//
//___|______________________________________________|___//
//|													   |//	
//======================================================//
//NAME: api_get_data(JsonElement json_object, String name)
//DESCRIPTION: sends a http request to the AW API, which responds with a json file
//ARGUMENTS: json_object (host and port of the api), name (the path for the api call)
//RETURNS: json_object with the API response, it is a Promise and needs to be listened with "await"
//NOTES: in order to be used, this function needs to be called with the "await" keyword form within an async function
function api_GetJson(json_obj,name){

	return new Promise(resolve=>{
		var req= new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+name
		var jsonResponse;

		req.open("GET",reqtext);	
		req.onload = function(){
			jsonResponse = JSON.parse(req.responseText);
			consoleLog(0,"api_GetJson: fetched data correctly from AW API")
			consoleLog(0,JSON.stringify(jsonResponse))
			resolve(jsonResponse) //return json asynchronously   
		}
		req.send();
	});

}
//===============================================================================================================







