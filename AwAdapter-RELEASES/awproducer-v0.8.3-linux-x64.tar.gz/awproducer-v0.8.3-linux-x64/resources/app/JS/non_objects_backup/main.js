/*---------------------------------------------------------\
| main.js: MAIN SCRIPT OF ACTIVITY WATCH PRODUCER
| 	DATE: 28/06/2022
| 	AUTHOR: Gregorio Monari
| 	DESCRIPTION: initializes the application
\---------------------------------------------------------*/

//GLOBAL VARIABLES
//--CONFIGURATION
var jsonConfig; //contains the localhost configuration
//TEMPORARY EVENTS CONTAINER, MAY CHANGE IN THE FUTURE
var watchers_json;
var WATCHERS=[]; //IDs OF EVERY WATCHER
var WATCHERS_CLIENTS=[];
var WATCHERS_HOST=[];
var events_json=[]; //EVENTS OF EVERY WATCHER
var events_table;
//TIMESTAMP FOR SYNCHRONIZATION, MUST REMAIN UNTOUCHED
var start_time="";
var end_time="";


//MAIN
console.log("//------------------\\\\")
console.log("|| AW PRODUCER V1.0 ||")
console.log("\\\\------------------//")
consoleLog(1,"### BEGINNING CONFIGURATION ###")

//INITIAL CONFIGURATION
init()
//get_current_timestamp();




//------------------
//INITIALIZE THE APP
async function init(){

	//[0] Get AW API hostname and port from json configuration
	jsonConfig = await get_aw_configuration('JS/config.json')
	consoleLog(0,JSON.stringify(jsonConfig))

	//[0.1] CREATE AW PRODUCER BUCKET
	await create_producer_bucket(jsonConfig)

	//[1] Get active watchers
	consoleLog(1,"### GETTING WATCHERS ###")
	watchers_json = await get_watchers(jsonConfig)
	
	//[2] Extract watchers ID
	consoleLog(1,"### EXTRACT WATCHERS IDs ###")
	var counter=0;
	for (key in watchers_json) {
		WATCHERS[counter]=watchers_json[key].id;
		counter=counter+1;
	}

	//[3] Get Watchers Events
	consoleLog(1,"### GETTING EVENTS ###")
	var start_time_json = await get_events(jsonConfig,"aw-producer")
	//IF START TIME EVENT EXISTS GET EVENTS SLICE, ELSE GET ALL EVENTS
	if(start_time_json.length){

		//GET FETTA DI EVENTI BABY
		start_time=start_time_json[0].data.last_update;
		end_time = get_current_timestamp();
		consoleLog(1,"fetching events from "+start_time+" to "+end_time)
		for (key in watchers_json) {
			events_json[key]=await query_events(jsonConfig,watchers_json[key].id,end_time,start_time);
		}

	}else{

		//GET ALL EVENTS
		consoleLog(1,"first run, fetching all events")
		end_time = get_current_timestamp();//FIX
		for(key in watchers_json){
			events_json[key]=await get_events(jsonConfig,watchers_json[key].id);
		}

	}

	//[3.1] 
	document.getElementById("sepabox_timestamp").innerHTML="<b>LAST UPDATE: </b>"+start_time+"<br><b>(to move)TO: </b>"+end_time;
	//msgg_info.innerHTML=msgg_info.innerHTML+"timeframe=> "+start_time+"||"+end_time+"<br>"

	//[4] PRINT ALL INFO FOR THE FIRST TIME
	consoleLog(1,"### UPDATING HTML ELEMENTS ###")
	//Print Watcher Info
	update_watcher_view(0)

	//[5] FORMAT INFO WITH DATATABLES.NET API
	$(document).ready( function () {
    	events_table=$('#events_table').DataTable();
	} );

}



//---------------------------------
//SEND DATA TO SEPA ON BUTTON PRESS
async function button_press(){

	consoleLog(1,"### BUTTON PRESSED, STARTING SEPA UPLOAD ###")
	//GET EVENTS DATA
	consoleLog(0,JSON.stringify(events_json))
	consoleLog(1,"fetched internal events object, starting upload procedure")

    //UPDATE MESSAGE
    for (key in watchers_json) {
        update_sepa_message(events_json[key],watchers_json[key].client,watchers_json[key].hostname); 
    } 


    //WHEN ALL UPDATES ARE DONE, CREATE UPDATE EVENT
    await update_event(jsonConfig,"{ \"timestamp\": \""+get_current_timestamp()+"\", \"duration\": 0, \"data\": {\"last_update\":\""+end_time+"\"} }")


}


function get_current_timestamp(){
	const date=new Date();
	var string_timestamp=date.toISOString()
	//console.log(stringa)
	return string_timestamp
}




//CHANGE WATCHER BUTTON?
var tempwatchnumb=1;
function cycle_watcher(){
	//UPDATE DATA
	update_watcher_view(tempwatchnumb)

	//CYCLE
	if (tempwatchnumb<WATCHERS.length-1) {
		tempwatchnumb=tempwatchnumb+1;
	}else{
		tempwatchnumb=0;
	}
}



//-----------------------------
//PRINT WATCHER INFO AND EVENTS
function update_watcher_view(n){

	var counter=0;
	for (key in watchers_json){
		if (counter==n) {
			format_watcher_info(watchers_json,watchers_json[key].id)

			delete_children("table_wrapper")
			create_table_structure("table_wrapper")
			create_events_table(events_json[key])
			break;
		}else{
			counter=counter+1;
		}
	}

	$(document).ready( function () {
    	events_table=$('#events_table').DataTable();
	} );

}


