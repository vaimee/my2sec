//--------------------
//SEPA CLIENT SCRIPT
//--------------------
console.log("-> Loaded external script: sepa_client.js")

//GLOBAL VARIABLES
let client; //GLOBAL OBJECT FOR THE SEPA CLIENT
var jsap;


//FETCH JSAP CONFIGURATION FILE AND CREATE SEPA CLIENT
fetch('JS/host.jsap')
.then(response => response.text())
.then(data => {
	jsap=JSON.parse(data)
	consoleLog(1,"sepaclient: parsed jsap (SEPAclient configuration file)")
	consoleLog(0,JSON.stringify(jsap))
	const SEPA = Sepajs.SEPA
	client= new SEPA(jsap)
	consoleLog(1,"sepaclient: Sepajs client created!")
	//send_sepa_message("ciao")
	var msg_host=document.getElementById("sepabox_host");
	msg_host.innerHTML="<b>HOST:</b> "+jsap.host+":"+jsap.sparql11protocol.port;
});




//SEND MESSAGE TO SEPA
/*
# STRUCTURE
insert {
	
	graph <http://example/user/GREG> {
	
		

	}	

}

*/
function update_sepa_message(jsonMessage,watcher_client,watcher_hostname){
	//var string="insert {<http://dld.arces.unibo.it/ontology/greg/messaggion"+String(counter)+"> <valore> '''"+JSON.stringify(jsonMessage)+"'''} where{}"
	var string="insert { _:b <hasValue> '''"+JSON.stringify(jsonMessage)+"'''; <hasClient> '''"+watcher_client+"'''; <hasHost> '''"+watcher_hostname+"'''} where{}"
	consoleLog(0,string)
	client.update(string)
	.then(()=>{
		consoleLog(1,"update_sepa_message: "+watcher_client +" EVENTS UPLOADED CORRECTLY!")
	});

}


//GET NUMBER OF MESSAGES SENT
/*
function get_message_counter(){
	return new Promise(resolve=>{
		client.query("select ?numero where {<messaggi> <numero> ?numero}")
		.then((data)=>{
			resolve(parseInt(data.results.bindings[0].numero.value));
		})
	})	
}

//UPDATE NUMBER OF MESSAGES SENT
function update_message_counter(n){
	client.update("delete {<messaggi> <numero> ?numero} insert {<messaggi> <numero> "+String(n)+"} where{<messaggi> <numero> ?numero}")
}
*/
