//======================================
// AW PRODUCER BUCKET AND EVENT HANDLERS
//======================================
//------------------------------
//NAME: create_producer_bucket(JsonElement json_obj)
//DESCRIPTION: creates a new "aw-producer" bucket. Does nothing if already exists
//NOTES:
function create_producer_bucket(json_obj){

	return new Promise(resolve=>{
		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer"
		req.open("POST", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"create_bucket: aw-producer bucket created, status "+this.status)
        		resolve("ok")
    		}else{

    			if (this.readyState === XMLHttpRequest.DONE && this.status === 304) {
    				consoleLog(1,"create_bucket: aw-producer bucket already existing, status "+this.status)
    				resolve("ok")
    			}

    		}
		}
		req.send("{ \"client\": \"aw-producer\", \"type\": \"sepaconnector\", \"hostname\": \"unknown\"}");	
	});

}




async function update_event(json_obj,json_event){

		var event= await get_events(jsonConfig,'aw-producer')
		//SE ESISTE GIA', ELIMINALO
		if (event.length>0) {
			await delete_event(jsonConfig,event[0].id)	
		}
		await create_event(jsonConfig,json_event)

}








function create_event(json_obj,json_event){

	return new Promise(resolve=>{

		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer/events"
		req.open("POST", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"create_event: aw-producer event created, status "+this.status)
        		resolve("ok")
    		}
		}
		//bodystring="{ \"timestamp\": \"2022-07-12T16:47:46.060Z\", \"duration\": 0, \"data\": {\"last_update\":\""+get_time()+"\"} }"
		req.send(json_event);	

	});
}




function delete_event(json_obj,event_ID){
	consoleLog(0,"removing event")
	return new Promise(resolve=>{

		var req = new XMLHttpRequest();
		var reqtext="http://"+json_obj.nodeHost+":"+json_obj.port+"/api/0/buckets/aw-producer/events/"+event_ID;
		req.open("DELETE", reqtext, true);

		//Send the proper header information along with the request
		req.setRequestHeader("Content-Type", "application/json");

		req.onreadystatechange = function() {// Call a function when the state changes.
    		if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        		// Request finished. Do processing here.
        		consoleLog(1,"remove_event: aw-producer event n."+event_ID+" deleted, status "+this.status)
        		resolve("ok")
    		}
		}
		req.send();	
	});
}