//--------------------
//SEPA CLIENT SCRIPT
//--------------------
console.log("-> Loaded external script: sepa_client.js")

//GLOBAL VARIABLES
let client; //GLOBAL OBJECT FOR THE SEPA CLIENT
//jsap; //E' DIVENTATA GLOBALE

init_sepa_client()

//FETCH JSAP CONFIGURATION FILE AND CREATE SEPA CLIENT
//fetch('JS/host.jsap')
//.then(response => response.text())
//.then(data => {
	//jsap=JSON.parse(data)
	//consoleLog(1,"sepaclient: parsed jsap (SEPAclient configuration file)")
	//consoleLog(0,JSON.stringify(jsap))
	//const SEPA = Sepajs.SEPA
	//client= new SEPA(jsap)
	//consoleLog(1,"sepaclient: Sepajs client created!")
	//send_sepa_message("ciao")
	//var msg_host=document.getElementById("sepabox_host");
	//msg_host.innerHTML="<b>HOST:</b> "+jsap.host+":"+jsap.sparql11protocol.port;
//});

var jsap;
function init_sepa_client(){

	consoleLog(1,"sepaclient: parsed jsap (SEPAclient configuration file)")
	consoleLog(0,JSON.stringify(jsap))
	const SEPA = Sepajs.SEPA
	client= new SEPA(jsap)
	consoleLog(1,"sepaclient: Sepajs client created!")
}


//SEND MESSAGE TO SEPA
/*
# STRUCTURE
insert {
	
	graph <http://www.vaimee.it/greg> {
	
		_:b <http://www.vaimee.it/ontology/sw#messageValue> '''json''';
			rdf:hasTimestamp '''dateTtime'''

	}	

}

*/
function update_sepa_message(jsonMessage,watcher_client,watcher_hostname){
	//var string="insert {<http://dld.arces.unibo.it/ontology/greg/messaggion"+String(counter)+"> <valore> '''"+JSON.stringify(jsonMessage)+"'''} where{}"
	var string="insert { _:b <hasValue> '''"+JSON.stringify(jsonMessage)+"'''; <hasClient> '''"+watcher_client+"'''; <hasHost> '''"+watcher_hostname+"'''} where{}"
	consoleLog(0,string)
	client.update(string)
	.then(()=>{
		consoleLog(1,"update_sepa_message: "+watcher_client +" EVENTS UPLOADED CORRECTLY!")
	});

}


function update_user_sepa_message(jsonMessage,watcher_client,username){
	//var string="insert {<http://dld.arces.unibo.it/ontology/greg/messaggion"+String(counter)+"> <valore> '''"+JSON.stringify(jsonMessage)+"'''} where{}"
	return new Promise(resolve=>{
		var string="insert { graph <http://www.vaimee.it/"+username+"> {_:b <http://www.vaimee.it/ontology/sw#messageValue> '''"+jsonMessage+"'''}} where{}"
		consoleLog(0,string)
		client.update(string)
		.then(()=>{
			consoleLog(1,"update_sepa_message: "+watcher_client +" EVENTS UPLOADED CORRECTLY!")
			resolve("updated");
			
		});
	});

}


function update_user_timed_sepa_message(jsonMessage,watcher_client,username,timestamp){
	//var string="insert {<http://dld.arces.unibo.it/ontology/greg/messaggion"+String(counter)+"> <valore> '''"+JSON.stringify(jsonMessage)+"'''} where{}"
	return new Promise(resolve=>{
		var string="insert { graph <http://www.vaimee.it/"+username+"> {_:b <http://www.vaimee.it/ontology/sw#messageValue> '''"+jsonMessage+"''' ; <http://www.w3.org/2006/time#inXSDDateTimeStamp> '''"+timestamp+"'''}} where{}"
		consoleLog(0,string)
		client.update(string)
		.then(()=>{
			consoleLog(1,"update_sepa_message: "+watcher_client +" EVENTS UPLOADED CORRECTLY!")
			resolve("updated");
			
		});
	});

}




function sub_events_count(username){

	consoleLog(1,"SUBSCRIBING TO MAPPINGS")

	var counter_el=document.getElementById("sub_counter");

	var NOTIFICATIONS_COUNT=0;

	const sub = client.subscribe("select (COUNT(?nodeid) AS ?nevents) where { graph <http://www.vaimee.it/"+username+"> {?nodeid <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://www.vaimee.it/ontology/sw#event> }} ")
	//const sub = client.subscribe("select (COUNT(?s) AS ?ntriples) where { graph <http://www.vaimee.it/"+username+"> {?s ?p ?o }} ")
	//const sub = client.subscribe("select * where { graph <http://www.vaimee.it/"+username+"> {?s ?p ?o }} ")
	//const sub = client.subscribe("select * where { ?g ?p ?o} ")
	
	//[0]ON SUBSCRIBE
	sub.on("subscribed",console.log)
	//g.consoleLog(1,"#### LISTENING TO NOTIFICATIONS ###\n")
	//[1]ON NOTIFICATION
	sub.on("notification", not => {
		consoleLog(1,"RECEIVED NOTIFICATION!");
		//consoleLog(0,JSON.stringify(not, null, 2));

		var bindings=extract_bindings(not);
		counter_el.textContent=bindings[0].nevents.value;

		//sub.unsubscribe()
		//NOTIFICATIONS_COUNT=NOTIFICATIONS_COUNT+1;
		//counter_el.textContent=NOTIFICATIONS_COUNT;
	})
	//[2]ON ERROR
	sub.on("error",console.error)	
}


var sepa_cbox=document.getElementById("sepa_connectionstatus_wrapper");
function echo_sepa(){
	return new Promise(resolve=>{



			client.query("select ?time where {<http://sepatest/currentTime> <http://sepatest/hasValue> ?time}")
			.then((data)=>{
				console.log("RECEIVED DATA");
				sepa_cbox.innerHTML="Connected to SEPA ("+jsap.host+":"+jsap.sparql11protocol.port+"<img class='' src='Assets/icons/wifi.svg'>)"
				resolve(data);
				document.getElementById("row-2").style.display="flex";
			});




	});	
}


function extract_bindings(msg){
	var bindings=msg.addedResults.results.bindings;
	return bindings;
}
